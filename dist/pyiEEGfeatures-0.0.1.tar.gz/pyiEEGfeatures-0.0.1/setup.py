# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['pyieegfeatures']

package_data = \
{'': ['*']}

install_requires = \
['scipy>=1.8.1,<2.0.0', 'seaborn>=0.11.2,<0.12.0', 'sklearn>=0.0,<0.1']

setup_kwargs = {
    'name': 'pyieegfeatures',
    'version': '0.0.1',
    'description': 'Useful functions for extracting features from iEEG signals',
    'long_description': None,
    'author': 'mariella',
    'author_email': 'mariella199098@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<3.11',
}


setup(**setup_kwargs)
